﻿Public Class ContentInfo
    Public Property IdContent As Integer
    Public Property ContentJP As String
    Public Property ContentVN As String
    Public Property IdUser As String
    Public Property IdPhase As Integer
    Public Property IdError As Integer
    Public Property Bug As Integer
    Public Property Reference As String
End Class
