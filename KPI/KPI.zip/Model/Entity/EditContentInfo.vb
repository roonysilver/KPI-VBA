﻿Public Class EditContentInfo
    Public Property IdTask As Integer
    Public Property Content As String
    Public Property Reason As String
    Public Property IdUser As String
    Public Property UserName As String
    Public Property FirstName As String
    Public Property FullName As String
    Public Property LastName As String
    Public Property IdLevel As Integer
    Public Property Level As String
    Public Property Levelja As String
    Public Property RowNumber As Integer
End Class
