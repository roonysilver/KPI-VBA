﻿Public Class ErrorAnalysisInfo
    Public Property IdErrorAnalysis As Integer
    Public Property IdPhase As Integer
    Public Property NamePhase As String
    Public Property NamePhaseJP As String
    Public Property FirstName As String
    Public Property LastName As String
    Public Property Content As String
    Public Property IdError As Integer
    Public Property NameError As String
    Public Property NameErrorJP As String
    Public Property Bug As Integer
    Public Property Reference As String
    Public Property Deleted As Integer
    Public Property CreateAt As Date
    Public Property UpdateAt As Date
    Public Property CreateBy As String
    Public Property UpdateBy As String
    Public Property Rownum As Integer
    Public Property IdQualityAnalysis As Integer
    Public Property IdTask As Integer

End Class
