﻿Public Class ProjectInfo
    Public Property IdProject As Integer
    Public Property NameProject As String
    Public Property CreateAt As DateTime
    Public Property UpdateAt As DateTime
    Public Property Description As String
    Public Property NameDepartment As String
    Public Property NameUser As String
    Public Property IdUser As String
    Public Property IdPL As String

    Public Property IdMember As String
    Public Property NameMember As String
    Public Property IdDepartment As Integer
End Class
