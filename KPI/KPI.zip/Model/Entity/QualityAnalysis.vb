﻿Public Class QualityAnalysis
    Public Property IdQualityAnalysis As Integer
    Public Property NamePhase As String
    Public Property Hour As Double
    Public Property Bug As Integer
    Public Property IdEditContent As Integer
End Class
