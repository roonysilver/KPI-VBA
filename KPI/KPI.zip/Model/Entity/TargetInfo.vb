﻿Public Class TargetInfo
    Public Property DesignTarget As Double = 0
    Public Property CodeTarget As Double = 0
    Public Property TestTarget As Double = 0
    Public Property AcceptBRCTarget As Double = 0
    Public Property AcceptOSCTarget As Double = 0
    Public Property AcceptProfessionTarget As Double = 0
End Class
