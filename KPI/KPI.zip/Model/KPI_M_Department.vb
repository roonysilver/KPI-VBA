﻿Public Class KPI_M_Department
    Public Property IdDepartment As Integer
    Public Property NameDepartment As String
End Class
