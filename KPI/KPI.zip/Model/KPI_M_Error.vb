﻿Public Class KPI_M_Error
    Public Property IdError As Integer
    Public Property NameError As String
    Public Property NameErrorJP As String
    Public Property Note As String
    Public Property CreateAt As DateTime
    Public Property UpdateAt As DateTime
    Public Property CreateBy As String
    Public Property UpdateBy As String
    Public Property IdErrorType As Integer
End Class
