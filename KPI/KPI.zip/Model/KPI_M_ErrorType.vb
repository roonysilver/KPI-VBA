﻿Public Class KPI_M_ErrorType
    Public Property IdErrorType As Integer
    Public Property NameErrorType As String
    Public Property CreateAt As DateTime
    Public Property UpdateAt As DateTime
    Public Property CreateBy As Integer
    Public Property UpdateBy As Integer
End Class
