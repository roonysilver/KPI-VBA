﻿Public Class KPI_M_Level
    Public Property IdLevel As Integer
    Public Property Level As String
    Public Property LevelJP As String
End Class
