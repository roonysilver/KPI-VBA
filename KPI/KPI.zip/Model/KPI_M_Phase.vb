﻿Public Class KPI_M_Phase
    Public Property IdPhase As Integer
    Public Property NamePhase As String
    Public Property NamePhaseJP As String
    Public Property Target As String
    Public Property TargetJP As String
End Class
