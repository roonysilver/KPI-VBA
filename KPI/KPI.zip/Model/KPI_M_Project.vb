﻿Public Class KPI_M_Project
    Public Property IdProject As Integer
    Public Property NameProject As String
    Public Property Description As String
    Public Property CreateAt As DateTime
    Public Property UpdateAt As DateTime
    Public Property Deleted As Integer
    Public Property IdDepartment As Integer
    Public Property CreateBy As String
    Public Property UpdateBy As String
End Class
