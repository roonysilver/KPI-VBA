﻿Public Class KPI_M_Role
    Public Property IdRole As Integer
    Public Property Name As String
End Class
