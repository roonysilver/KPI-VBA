﻿Public Class KPI_M_User
    Public Property IdUser As String
    Public Property Username As String
    Public Property PassWord As String
    Public Property IdRole As Integer
    Public Property FirstName As String
    Public Property LastName As String
    Public Property Dob As Date
    Public Property Address As String
    Public Property Phone As String
    Public Property email As String
    Public Property Token As String
    Public Property TimeForget As DateTime
    Public Property LoginFail As Integer
    Public Property IdProject As Integer
End Class
