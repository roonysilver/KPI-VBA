﻿Public Class KPI_T_ErrorAnalysis
    Public Property IdErrorAnalysis As Integer
    Public Property IdEditContent As Integer
    Public Property idPhase As String
    Public Property Bug As Integer
    Public Property Reference As Integer
    Public Property IdError As Integer
    Public Property Deleted As Integer
    Public Property CreateAt As DateTime
    Public Property UpdateAt As DateTime
    Public Property CreateBy As String
    Public Property UpdateBy As String
    Public Property Rownum As Integer
End Class
