﻿Public Class KPI_T_ProjectUser

    Public Property IdProjectUser As Integer
    Public Property IdUser As String
    Public Property IdProject As Integer
End Class
