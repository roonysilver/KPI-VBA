﻿Public Class KPI_T_QualityAnalysis
    Public Property IdQualityAnalysis As Integer
    Public Property Hour As Double
    Public Property IdEditContent As Integer
    Public Property IdPhase As Integer
    Public Property Deleted As Integer
End Class
