﻿Public Class KPI_T_Task
    Public Property IdTask As Integer
    Public Property IdErrorAnalysis As Integer
    Public Property Content As String
    Public Property Reason As String
    Public Property IdLevel As Integer
    Public Property Level As String
    Public Property LevelJP As String
    Public Property IdUser As String
    Public Property FirstName As String
    Public Property LastName As String
    Public Property IdProject As Integer
    Public Property NameProject As String
    Public Property CreateAt As DateTime
    Public Property UpdateAt As DateTime
    Public Property CreateBy As String
    Public Property UpdateBy As String
    Public Property RowNum As Integer
End Class
