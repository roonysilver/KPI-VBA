﻿Public Interface IPhase
    Function GetListPhase() As List(Of KPI_M_Phase)
End Interface
